let inventoryForm = document.getElementById("inventoryForm");
inventoryForm.addEventListener("submit", (e) => {
    e.preventDefault();
    var apples = document.getElementById("apples").value;
    var bananas = document.getElementById("bananas").value;
    var carrots = document.getElementById("carrots").value;
    var milk = document.getElementById("milk").value;
  });